/** Automatically generated file. DO NOT MODIFY */
package com.jbutewicz.timepickeractivitynew;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}